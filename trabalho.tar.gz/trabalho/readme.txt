Verificando estado do registro de ativacao

size heap_test 


---------------- %ebp
stack
||



||
heap
---------------- brk
bss (uninitialized)
----------------
data (initialized)
#define MAX_ELEM 16
#define TAM_MAX  64
#define NUM_OPER 32
---------------- 4(%esp) (first argument)
---------------- %esp (return address)
text


